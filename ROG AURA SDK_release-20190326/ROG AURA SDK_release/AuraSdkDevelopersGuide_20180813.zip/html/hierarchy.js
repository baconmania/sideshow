var hierarchy =
[
    [ "AuraServiceLib::AuraSdk", "class_aura_service_lib_1_1_aura_sdk.html", null ],
    [ "AuraServiceLib::IAuraRgbKeyCollection", "interface_aura_service_lib_1_1_i_aura_rgb_key_collection.html", null ],
    [ "AuraServiceLib::IAuraRgbLight", "interface_aura_service_lib_1_1_i_aura_rgb_light.html", [
      [ "AuraServiceLib::IAuraRgbKey", "interface_aura_service_lib_1_1_i_aura_rgb_key.html", null ]
    ] ],
    [ "AuraServiceLib::IAuraRgbLightCollection", "interface_aura_service_lib_1_1_i_aura_rgb_light_collection.html", null ],
    [ "AuraServiceLib::IAuraSdk", "interface_aura_service_lib_1_1_i_aura_sdk.html", [
      [ "AuraServiceLib::IAuraSdk2", "interface_aura_service_lib_1_1_i_aura_sdk2.html", null ]
    ] ],
    [ "AuraServiceLib::IAuraSyncDevice", "interface_aura_service_lib_1_1_i_aura_sync_device.html", [
      [ "AuraServiceLib::IAuraSyncKeyboard", "interface_aura_service_lib_1_1_i_aura_sync_keyboard.html", null ]
    ] ],
    [ "AuraServiceLib::IAuraSyncDeviceCollection", "interface_aura_service_lib_1_1_i_aura_sync_device_collection.html", null ]
];