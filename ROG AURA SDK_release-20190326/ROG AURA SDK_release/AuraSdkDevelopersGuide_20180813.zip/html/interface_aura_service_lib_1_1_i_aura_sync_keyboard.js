var interface_aura_service_lib_1_1_i_aura_sync_keyboard =
[
    [ "Key", "interface_aura_service_lib_1_1_i_aura_sync_keyboard.html#aeefb4f9be27f1d976617775a6ee8a9f9", null ],
    [ "Keys", "interface_aura_service_lib_1_1_i_aura_sync_keyboard.html#a30f8fd28e1b1702832a41c9244010706", null ]
];