var interface_aura_service_lib_1_1_i_aura_rgb_light =
[
    [ "Blue", "interface_aura_service_lib_1_1_i_aura_rgb_light.html#ad4322792c7ac4968654ff5c3aea352cd", null ],
    [ "Color", "interface_aura_service_lib_1_1_i_aura_rgb_light.html#a94db0bee3965a8c302ea9d6d7d3ecb4c", null ],
    [ "Green", "interface_aura_service_lib_1_1_i_aura_rgb_light.html#a60d7937d233ec88a485839d46ecab1f4", null ],
    [ "Name", "interface_aura_service_lib_1_1_i_aura_rgb_light.html#a8cd9b13ebbbfb16d6e9d51d114dc0e04", null ],
    [ "Red", "interface_aura_service_lib_1_1_i_aura_rgb_light.html#a4d263947538e32bc6fcba67f26bb4c24", null ]
];