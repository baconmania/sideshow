var interface_aura_service_lib_1_1_i_aura_rgb_key =
[
    [ "Code", "interface_aura_service_lib_1_1_i_aura_rgb_key.html#a10a2a06aafce4c77cb040effd079665e", null ],
    [ "X", "interface_aura_service_lib_1_1_i_aura_rgb_key.html#a2b514198b2fa9bcbf4f65d00bf8c0a2b", null ],
    [ "Y", "interface_aura_service_lib_1_1_i_aura_rgb_key.html#a56f2f62094302deba98965701b04606c", null ]
];