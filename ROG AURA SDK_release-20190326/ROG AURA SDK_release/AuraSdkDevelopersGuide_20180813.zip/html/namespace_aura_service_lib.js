var namespace_aura_service_lib =
[
    [ "AuraSdk", "class_aura_service_lib_1_1_aura_sdk.html", null ],
    [ "IAuraRgbKey", "interface_aura_service_lib_1_1_i_aura_rgb_key.html", "interface_aura_service_lib_1_1_i_aura_rgb_key" ],
    [ "IAuraRgbKeyCollection", "interface_aura_service_lib_1_1_i_aura_rgb_key_collection.html", "interface_aura_service_lib_1_1_i_aura_rgb_key_collection" ],
    [ "IAuraRgbLight", "interface_aura_service_lib_1_1_i_aura_rgb_light.html", "interface_aura_service_lib_1_1_i_aura_rgb_light" ],
    [ "IAuraRgbLightCollection", "interface_aura_service_lib_1_1_i_aura_rgb_light_collection.html", "interface_aura_service_lib_1_1_i_aura_rgb_light_collection" ],
    [ "IAuraSdk", "interface_aura_service_lib_1_1_i_aura_sdk.html", "interface_aura_service_lib_1_1_i_aura_sdk" ],
    [ "IAuraSdk2", "interface_aura_service_lib_1_1_i_aura_sdk2.html", "interface_aura_service_lib_1_1_i_aura_sdk2" ],
    [ "IAuraSyncDevice", "interface_aura_service_lib_1_1_i_aura_sync_device.html", "interface_aura_service_lib_1_1_i_aura_sync_device" ],
    [ "IAuraSyncDeviceCollection", "interface_aura_service_lib_1_1_i_aura_sync_device_collection.html", "interface_aura_service_lib_1_1_i_aura_sync_device_collection" ],
    [ "IAuraSyncKeyboard", "interface_aura_service_lib_1_1_i_aura_sync_keyboard.html", "interface_aura_service_lib_1_1_i_aura_sync_keyboard" ]
];