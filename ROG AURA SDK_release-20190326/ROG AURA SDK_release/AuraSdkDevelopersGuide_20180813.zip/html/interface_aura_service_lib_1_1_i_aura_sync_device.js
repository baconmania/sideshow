var interface_aura_service_lib_1_1_i_aura_sync_device =
[
    [ "Apply", "interface_aura_service_lib_1_1_i_aura_sync_device.html#a28aa1deea58a9ec9a11435372ab7b05f", null ],
    [ "Height", "interface_aura_service_lib_1_1_i_aura_sync_device.html#a8c90e064b56743df075b6d80d87bd13c", null ],
    [ "Lights", "interface_aura_service_lib_1_1_i_aura_sync_device.html#af5c57839bf3d5aef267332b9ee896af6", null ],
    [ "Name", "interface_aura_service_lib_1_1_i_aura_sync_device.html#a67bc36cb49649de8b97c630075f5502d", null ],
    [ "Type", "interface_aura_service_lib_1_1_i_aura_sync_device.html#a9aa849b58fc26141ecefdb53e0c6bd81", null ],
    [ "Width", "interface_aura_service_lib_1_1_i_aura_sync_device.html#a0698164c7dbbbeac2e78c245abdf9ee7", null ]
];