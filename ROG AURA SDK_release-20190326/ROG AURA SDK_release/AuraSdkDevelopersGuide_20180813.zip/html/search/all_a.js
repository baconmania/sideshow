var searchData=
[
  ['name',['Name',['../interface_aura_service_lib_1_1_i_aura_sync_device.html#a67bc36cb49649de8b97c630075f5502d',1,'AuraServiceLib::IAuraSyncDevice::Name()'],['../interface_aura_service_lib_1_1_i_aura_rgb_light.html#a8cd9b13ebbbfb16d6e9d51d114dc0e04',1,'AuraServiceLib::IAuraRgbLight::Name()']]]
];
