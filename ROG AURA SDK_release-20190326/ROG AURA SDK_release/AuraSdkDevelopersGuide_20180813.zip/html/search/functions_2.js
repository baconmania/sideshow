var searchData=
[
  ['releasecontrol',['ReleaseControl',['../interface_aura_service_lib_1_1_i_aura_sdk2.html#a8b8fd82877d329cf09d8e81a0ed1a519',1,'AuraServiceLib::IAuraSdk2']]]
];
