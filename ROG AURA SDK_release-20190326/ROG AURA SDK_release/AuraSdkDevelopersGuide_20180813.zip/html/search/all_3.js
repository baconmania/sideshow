var searchData=
[
  ['code',['Code',['../interface_aura_service_lib_1_1_i_aura_rgb_key.html#a10a2a06aafce4c77cb040effd079665e',1,'AuraServiceLib::IAuraRgbKey']]],
  ['color',['Color',['../interface_aura_service_lib_1_1_i_aura_rgb_light.html#a94db0bee3965a8c302ea9d6d7d3ecb4c',1,'AuraServiceLib::IAuraRgbLight']]],
  ['count',['Count',['../interface_aura_service_lib_1_1_i_aura_rgb_light_collection.html#ab05cca1208e386f2745e732e5f1e19bc',1,'AuraServiceLib::IAuraRgbLightCollection::Count()'],['../interface_aura_service_lib_1_1_i_aura_rgb_key_collection.html#a9bec5b2ea662bb97d4a323718f6d016b',1,'AuraServiceLib::IAuraRgbKeyCollection::Count()'],['../interface_aura_service_lib_1_1_i_aura_sync_device_collection.html#afd0dd67ca976e9527ef3b1e9b7f8be8b',1,'AuraServiceLib::IAuraSyncDeviceCollection::Count()']]],
  ['c_2b_2b_20tutorial',['C++ Tutorial',['../tutorial_cpp.html',1,'tutorial']]],
  ['c_23_20tutorial',['C# Tutorial',['../tutorial_csharp.html',1,'tutorial']]]
];
