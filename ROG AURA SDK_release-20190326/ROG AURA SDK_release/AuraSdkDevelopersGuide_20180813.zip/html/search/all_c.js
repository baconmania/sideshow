var searchData=
[
  ['red',['Red',['../interface_aura_service_lib_1_1_i_aura_rgb_light.html#a4d263947538e32bc6fcba67f26bb4c24',1,'AuraServiceLib::IAuraRgbLight']]],
  ['releasecontrol',['ReleaseControl',['../interface_aura_service_lib_1_1_i_aura_sdk2.html#a8b8fd82877d329cf09d8e81a0ed1a519',1,'AuraServiceLib::IAuraSdk2']]]
];
