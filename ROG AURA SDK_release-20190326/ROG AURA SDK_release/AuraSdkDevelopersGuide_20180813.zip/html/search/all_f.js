var searchData=
[
  ['width',['Width',['../interface_aura_service_lib_1_1_i_aura_sync_device.html#a0698164c7dbbbeac2e78c245abdf9ee7',1,'AuraServiceLib::IAuraSyncDevice']]]
];
