var searchData=
[
  ['_5fnewenum',['_NewEnum',['../interface_aura_service_lib_1_1_i_aura_rgb_light_collection.html#ad44fe2516d2105656dfd0d1ac9da6c03',1,'AuraServiceLib::IAuraRgbLightCollection::_NewEnum()'],['../interface_aura_service_lib_1_1_i_aura_rgb_key_collection.html#ad4db040366433c7d453e71f21589845f',1,'AuraServiceLib::IAuraRgbKeyCollection::_NewEnum()'],['../interface_aura_service_lib_1_1_i_aura_sync_device_collection.html#ac1c0ff1365df9e0d522eaa50f74d63ec',1,'AuraServiceLib::IAuraSyncDeviceCollection::_NewEnum()']]]
];
