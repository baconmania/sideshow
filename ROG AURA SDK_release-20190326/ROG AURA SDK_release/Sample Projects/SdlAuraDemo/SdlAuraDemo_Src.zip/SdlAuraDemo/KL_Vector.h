#ifndef __KL_VECTOR_H__
#define __KL_VECTOR_H__

#include <SDL_rect.h>

class KL_Vector2D
{
public:
	float x;
	float y;

	KL_Vector2D(float _x = 0.0f, float _y = 0.0f);

	~KL_Vector2D() {}

	void normalize();

	void scale(float s);
};

#endif
