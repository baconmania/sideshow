#pragma once

#define ROG_KEY_ESCAPE          0x01
#define ROG_KEY_1               0x02
#define ROG_KEY_2               0x03
#define ROG_KEY_3               0x04
#define ROG_KEY_4               0x05
#define ROG_KEY_5               0x06
#define ROG_KEY_6               0x07
#define ROG_KEY_7               0x08
#define ROG_KEY_8               0x09
#define ROG_KEY_9               0x0A
#define ROG_KEY_0               0x0B
#define ROG_KEY_MINUS           0x0C    /* - on main keyboard */
#define ROG_KEY_EQUALS          0x0D
#define ROG_KEY_BACK            0x0E    /* backspace */
#define ROG_KEY_TAB             0x0F
#define ROG_KEY_Q               0x10
#define ROG_KEY_W               0x11
#define ROG_KEY_E               0x12
#define ROG_KEY_R               0x13
#define ROG_KEY_T               0x14
#define ROG_KEY_Y               0x15
#define ROG_KEY_U               0x16
#define ROG_KEY_I               0x17
#define ROG_KEY_O               0x18
#define ROG_KEY_P               0x19
#define ROG_KEY_LBRACKET        0x1A
#define ROG_KEY_RBRACKET        0x1B
#define ROG_KEY_RETURN          0x1C    /* Enter on main keyboard */
#define ROG_KEY_LCONTROL        0x1D
#define ROG_KEY_A               0x1E
#define ROG_KEY_S               0x1F
#define ROG_KEY_D               0x20
#define ROG_KEY_F               0x21
#define ROG_KEY_G               0x22
#define ROG_KEY_H               0x23
#define ROG_KEY_J               0x24
#define ROG_KEY_K               0x25
#define ROG_KEY_L               0x26
#define ROG_KEY_SEMICOLON       0x27
#define ROG_KEY_APOSTROPHE      0x28
#define ROG_KEY_GRAVE           0x29    /* accent grave */
#define ROG_KEY_LSHIFT          0x2A
#define ROG_KEY_BACKSLASH       0x2B
#define ROG_KEY_Z               0x2C
#define ROG_KEY_X               0x2D
#define ROG_KEY_C               0x2E
#define ROG_KEY_V               0x2F
#define ROG_KEY_B               0x30
#define ROG_KEY_N               0x31
#define ROG_KEY_M               0x32
#define ROG_KEY_COMMA           0x33
#define ROG_KEY_PERIOD          0x34    /* . on main keyboard */
#define ROG_KEY_SLASH           0x35    /* / on main keyboard */
#define ROG_KEY_RSHIFT          0x36
#define ROG_KEY_MULTIPLY        0x37    /* * on numeric keypad */
#define ROG_KEY_LMENU           0x38    /* left Alt */
#define ROG_KEY_SPACE           0x39
#define ROG_KEY_CAPITAL         0x3A
#define ROG_KEY_F1              0x3B
#define ROG_KEY_F2              0x3C
#define ROG_KEY_F3              0x3D
#define ROG_KEY_F4              0x3E
#define ROG_KEY_F5              0x3F
#define ROG_KEY_F6              0x40
#define ROG_KEY_F7              0x41
#define ROG_KEY_F8              0x42
#define ROG_KEY_F9              0x43
#define ROG_KEY_F10             0x44
#define ROG_KEY_NUMLOCK         0x45
#define ROG_KEY_SCROLL          0x46    /* Scroll Lock */
#define ROG_KEY_NUMPAD7         0x47
#define ROG_KEY_NUMPAD8         0x48
#define ROG_KEY_NUMPAD9         0x49
#define ROG_KEY_SUBTRACT        0x4A    /* - on numeric keypad */
#define ROG_KEY_NUMPAD4         0x4B
#define ROG_KEY_NUMPAD5         0x4C
#define ROG_KEY_NUMPAD6         0x4D
#define ROG_KEY_ADD             0x4E    /* + on numeric keypad */
#define ROG_KEY_NUMPAD1         0x4F
#define ROG_KEY_NUMPAD2         0x50
#define ROG_KEY_NUMPAD3         0x51
#define ROG_KEY_NUMPAD0         0x52
#define ROG_KEY_DECIMAL         0x53    /* . on numeric keypad */
//#define ROG_KEY_OEM_102         0x56    /* < > | on UK/Germany keyboards */
#define ROG_KEY_F11             0x57
#define ROG_KEY_F12             0x58
//#define ROG_KEY_F13             0x64    /*                     (NEC PC98) */
//#define ROG_KEY_F14             0x65    /*                     (NEC PC98) */
//#define ROG_KEY_F15             0x66    /*                     (NEC PC98) */
//#define ROG_KEY_KANA            0x70    /* (Japanese keyboard)            */
//#define ROG_KEY_ABNT_C1         0x73    /* / ? on Portugese (Brazilian) keyboards */
//#define ROG_KEY_CONVERT         0x79    /* (Japanese keyboard)            */
//#define ROG_KEY_NOCONVERT       0x7B    /* (Japanese keyboard)            */
//#define ROG_KEY_YEN             0x7D    /* (Japanese keyboard)            */
//#define ROG_KEY_ABNT_C2         0x7E    /* Numpad . on Portugese (Brazilian) keyboards */
//#define ROG_KEY_NUMPADEQUALS    0x8D    /* = on numeric keypad (NEC PC98) */
//#define ROG_KEY_CIRCUMFLEX      0x90    /* (Japanese keyboard)            */
//#define ROG_KEY_AT              0x91    /*                     (NEC PC98) */
//#define ROG_KEY_COLON           0x92    /*                     (NEC PC98) */
//#define ROG_KEY_UNDERLINE       0x93    /*                     (NEC PC98) */
//#define ROG_KEY_KANJI           0x94    /* (Japanese keyboard)            */
//#define ROG_KEY_STOP            0x95    /*                     (NEC PC98) */
//#define ROG_KEY_AX              0x96    /*                     (Japan AX) */
//#define ROG_KEY_UNLABELED       0x97    /*                        (J3100) */
//#define ROG_KEY_NEXTTRACK       0x99    /* Next Track */
#define ROG_KEY_NUMPADENTER     0x9C    /* Enter on numeric keypad */
#define ROG_KEY_RCONTROL        0x9D
//#define ROG_KEY_MUTE	    0xA0    /* Mute */
//#define ROG_KEY_CALCULATOR      0xA1    /* Calculator */
//#define ROG_KEY_PLAYPAUSE       0xA2    /* Play / Pause */
//#define ROG_KEY_MEDIASTOP       0xA4    /* Media Stop */
//#define ROG_KEY_VOLUMEDOWN      0xAE    /* Volume - */
//#define ROG_KEY_VOLUMEUP        0xB0    /* Volume + */
//#define ROG_KEY_WEBHOME         0xB2    /* Web home */
//#define ROG_KEY_NUMPADCOMMA     0xB3    /* , on numeric keypad (NEC PC98) */
#define ROG_KEY_DIVIDE          0xB5    /* / on numeric keypad */
#define ROG_KEY_SYSRQ           0xB7
#define ROG_KEY_RMENU           0xB8    /* right Alt */
#define ROG_KEY_PAUSE           0xC5    /* Pause */
#define ROG_KEY_HOME            0xC7    /* Home on arrow keypad */
#define ROG_KEY_UP              0xC8    /* UpArrow on arrow keypad */
#define ROG_KEY_PRIOR           0xC9    /* PgUp on arrow keypad */
#define ROG_KEY_LEFT            0xCB    /* LeftArrow on arrow keypad */
#define ROG_KEY_RIGHT           0xCD    /* RightArrow on arrow keypad */
#define ROG_KEY_END             0xCF    /* End on arrow keypad */
#define ROG_KEY_DOWN            0xD0    /* DownArrow on arrow keypad */
#define ROG_KEY_NEXT            0xD1    /* PgDn on arrow keypad */
#define ROG_KEY_INSERT          0xD2    /* Insert on arrow keypad */
#define ROG_KEY_DELETE          0xD3    /* Delete on arrow keypad */
#define ROG_KEY_LWIN            0xDB    /* Left Windows key */
//#define ROG_KEY_RWIN            0xDC    /* Right Windows key */
#define ROG_KEY_APPS            0xDD    /* AppMenu key */
//#define ROG_KEY_POWER           0xDE
//#define ROG_KEY_SLEEP           0xDF
//#define ROG_KEY_WAKE            0xE3    /* System Wake */
//#define ROG_KEY_WEBSEARCH       0xE5    /* Web Search */
//#define ROG_KEY_WEBFAVORITES    0xE6    /* Web Favorites */
//#define ROG_KEY_WEBREFRESH      0xE7    /* Web Refresh */
//#define ROG_KEY_WEBSTOP         0xE8    /* Web Stop */
//#define ROG_KEY_WEBFORWARD      0xE9    /* Web Forward */
//#define ROG_KEY_WEBBACK         0xEA    /* Web Back */
//#define ROG_KEY_MYCOMPUTER      0xEB    /* My Computer */
//#define ROG_KEY_MAIL            0xEC    /* Mail */
//#define ROG_KEY_MEDIASELECT     0xED    /* Media Select */
#define ROG_KEY_FN                0x100   /* Function key */
#define ROG_KEY_LOGO              0x101   /* ROG logo light */
#define ROG_KEY_LSIDE             0x102   /* Left side light*/
#define ROG_KEY_RSIDE             0x103   /* Right side light */