#include "KL_Vector.h"

#include <cmath>

using namespace std;

KL_Vector2D::KL_Vector2D(float _x, float _y)
	: x(_x)
	, y(_y)
{
}

void KL_Vector2D::normalize()
{
	float len = sqrt(x * x + y * y);
	if (len > 0.00001)
	{
		x /= len;
		y /= len;
	}
	else
	{
		x = 0.0f;
		y = 0.0f;
	}
}

void KL_Vector2D::scale(float s)
{
	x *= s;
	y *= s;
}
