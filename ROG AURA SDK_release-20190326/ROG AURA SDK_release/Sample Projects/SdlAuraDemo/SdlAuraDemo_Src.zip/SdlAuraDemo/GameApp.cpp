#include "GameApp.h"

#include <algorithm>
#include <iostream>
#include <string>
#include <SDL_image.h>

#include "RogInput.h"

using namespace std;

constexpr int TARGET_FPS = 60;


GameApp::GameApp(int width, int height)
	: m_ledDevMgr(new LedDeviceManager())
	, m_bInitOk(false)
	, m_width(width)
	, m_height(height)
	, m_window(nullptr)
	, m_renderer(nullptr)
	, m_font(nullptr)
	, m_texCrosshair(nullptr)
	, m_texAmmoText(nullptr)
	, m_posCrosshair({ 0.0f, 0.0f })
	, m_velocity(300.0f / TARGET_FPS)
	, m_maxAmmoCount(10)
	, m_curAmmoCount(10)
	, m_screenFlashState(0)
	, m_bReload(false)
	, m_reloadFrameCount(0)
	, m_led_breathingFrame(0)
	, m_led_reloadFrame(0)
{
	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		cout << "SDL Cannot be initialized.\nSDL Error: " << SDL_GetError() << endl;
	}
	else
	{
		m_bInitOk = true;
		m_init();

		m_loadMedia();
	}
}


GameApp::~GameApp()
{
	delete m_texAmmoText;
	m_texAmmoText = nullptr;

	delete m_texCrosshair;
	m_texCrosshair = nullptr;

	if (m_font)
	{
		TTF_CloseFont(m_font);
	}

	if (m_renderer)
	{
		SDL_DestroyRenderer(m_renderer);
	}

	if (m_window)
	{
		SDL_DestroyWindow(m_window);
	}

	TTF_Quit();
	IMG_Quit();
	SDL_Quit();
}

void GameApp::m_init()
{
	// Create window
	m_window = SDL_CreateWindow(
		"Aura Demo",
		SDL_WINDOWPOS_CENTERED,
		SDL_WINDOWPOS_CENTERED,
		m_width,
		m_height,
		SDL_WINDOW_SHOWN);

	if (!m_window)
	{
		cout << "Cannot create SDL window.\nSDL Error: " << SDL_GetError() << endl;
		return;
	}

	// Set texture filtering to linear
	SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "1");

	m_renderer = SDL_CreateRenderer(m_window, -1, SDL_RENDERER_ACCELERATED);
	if (!m_renderer)
	{
		cout << "Cannot create renderer!\nSDL Error: " << SDL_GetError() << endl;
		return;
	}

	// Initialize renderer color
	SDL_SetRenderDrawColor(m_renderer, 0x00, 0x00, 0x00, 0xFF);

	// Initialize IMG module for PNG loading
	int imgFlags = IMG_INIT_PNG;
	if (!(IMG_Init(imgFlags) & imgFlags))
	{
		cout << "SDL_image could not initialize!\nSDL_image Error: " << IMG_GetError() << endl;
		return;
	}

	// Initialize TTF module
	if (TTF_Init() == -1)
	{
		cout << "Cannot initialize TTF!\nSDL_ttf Errir: " << TTF_GetError() << endl;
		return;
	}
}

void GameApp::m_loadMedia()
{
	m_texCrosshair = new GameTexture("images/crosshair.png", m_renderer);

	m_font = TTF_OpenFont("YouAreGone.ttf", 36);
	if (!m_font)
	{
		cout << "SDL_ttf cannot load font \"YouAreGone.ttf\"!\nSDL_ttf Error: "
			<< TTF_GetError() << endl;
		return;
	}
	m_updateAmmoTexture();

	m_texReload = new GameTexture("images/reload.png", m_renderer);
	m_texReload->setPosition(SDL_Point({ SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2 }));
}

void GameApp::m_updateCrosshairPos()
{
	KL_Vector2D vec;
	auto key_state = SDL_GetKeyboardState(nullptr);
	if (key_state[SDL_SCANCODE_W])
	{
		vec.y -= 1.0f;
	}
	if (key_state[SDL_SCANCODE_S])
	{
		vec.y += 1.0f;
	}
	if (key_state[SDL_SCANCODE_A])
	{
		vec.x -= 1.0f;
	}
	if (key_state[SDL_SCANCODE_D])
	{
		vec.x += 1.0f;
	}

	vec.normalize();
	vec.scale(m_velocity);

	m_posCrosshair.x = min<float>(
		max<float>(m_posCrosshair.x + vec.x, 0.0f),
		static_cast<float>(SCREEN_WIDTH));
	m_posCrosshair.y = min<float>(
		max<float>(m_posCrosshair.y + vec.y, 0.0f),
		static_cast<float>(SCREEN_HEIGHT));
}

void GameApp::m_updateAmmoTexture()
{
	string str_ammo("Ammo: ");
	str_ammo += to_string(m_curAmmoCount);
	str_ammo += " / ";
	str_ammo += to_string(m_maxAmmoCount);

	m_texAmmoText = new GameTexture();
	if (!m_texAmmoText->loadText(
		str_ammo,
		SDL_Color({ 0xFF, 0xFF, 0xFF, 0xFF }),
		*m_font,
		m_renderer))
	{
		cout << "Cannot render text texture!" << endl;
		return;
	}

	// Update position
	SDL_Point pos;
	pos.x = m_texAmmoText->getWidth() / 2 + 20;
	pos.y = SCREEN_HEIGHT - m_texAmmoText->getHeight() / 2 - 20;
	m_texAmmoText->setPosition(pos);
}

void GameApp::m_doLedCtrl()
{
	// Some logics might need to be calculated every frame, so do it out of the "IsReady()" check.
	(++m_led_breathingFrame) %= (TARGET_FPS * 4);
	float breathing_scale = 0.0f;
	if (m_led_breathingFrame < (TARGET_FPS * 3 / 2))
	{
		breathing_scale = static_cast<float>(m_led_breathingFrame) / (TARGET_FPS * 1.5f);
	}
	else if (m_led_breathingFrame < (TARGET_FPS * 2))
	{
		breathing_scale = 1.0f;
	}
	else if (m_led_breathingFrame < (TARGET_FPS * 7 / 2))
	{
		breathing_scale = static_cast<float>(TARGET_FPS * 7 / 2 - m_led_breathingFrame) / (TARGET_FPS * 1.5f);
	}
	else
	{
		breathing_scale = 0.0f;
	}
	COLORREF theme_color;
	{
		// Breathing effect
		theme_color = RGB(0x00, 0x00, static_cast<unsigned char>(breathing_scale * 0xFF));
	}

	// Apply LED states only when LED devices are not busy...
	if (m_ledDevMgr->IsReady())
	{
		// LED effect must be handled inside IsReady(); otherwise it might lost sometimes.
		if (m_led_flash)
		{
			// The flashing effect should override default breathing effect.
			theme_color = RGB(0xFF, 0xFF, 0x00);
			m_led_flash = false;
		}

		auto dev_count = m_ledDevMgr->GetDeviceCount();
		// Set color to all devices.
		for (size_t i = 0; i < dev_count; i++)
		{
			auto& device = m_ledDevMgr->GetDevice(i);
			device.SetColorToAllLights(theme_color);

			// Some keys should be handled independently...
			if (device.GetType() == LedDeviceType::KEYBOARD_RGB ||
				device.GetType() == LedDeviceType::NB_KB_RGB)
			{
				// W-A-S-D and SPACE must be WHITE all the time.
				device.SetColorByScanCode(ROG_KEY_W, RGB(0xFF, 0xFF, 0xFF));
				device.SetColorByScanCode(ROG_KEY_A, RGB(0xFF, 0xFF, 0xFF));
				device.SetColorByScanCode(ROG_KEY_S, RGB(0xFF, 0xFF, 0xFF));
				device.SetColorByScanCode(ROG_KEY_D, RGB(0xFF, 0xFF, 0xFF));
				device.SetColorByScanCode(ROG_KEY_SPACE, RGB(0xFF, 0xFF, 0xFF));

				// R should be flashing when Reload is needed.
				if (m_bReload)
				{
					auto scale = static_cast<unsigned char>((sin((double)m_reloadFrameCount / TARGET_FPS * 2 * M_PI) * 0.5 + 0.5) * 0xFF);
					device.SetColorByScanCode(ROG_KEY_R, RGB(scale, scale, scale));
					device.SetColorByScanCode(ROG_KEY_LSIDE, RGB(scale, scale, scale));
					device.SetColorByScanCode(ROG_KEY_RSIDE, RGB(scale, scale, scale));
					device.SetColorByScanCode(ROG_KEY_LOGO, RGB(scale, scale, scale));
				}

				// F1 ~ F4: Ammo count status
				device.SetColorByScanCode(ROG_KEY_F1, m_curAmmoCount > 0 ? RGB(0x00, 0xFF, 0x00) : RGB(0xFF, 0x00, 0x00));
				device.SetColorByScanCode(ROG_KEY_F2, m_curAmmoCount > 3 ? RGB(0x00, 0xFF, 0x00) : RGB(0xFF, 0x00, 0x00));
				device.SetColorByScanCode(ROG_KEY_F3, m_curAmmoCount > 5 ? RGB(0x00, 0xFF, 0x00) : RGB(0xFF, 0x00, 0x00));
				device.SetColorByScanCode(ROG_KEY_F4, m_curAmmoCount > 8 ? RGB(0x00, 0xFF, 0x00) : RGB(0xFF, 0x00, 0x00));
			}
		}

		m_ledDevMgr->ApplyAll();
	}
}

int GameApp::Run()
{
	bool bQuit = false;
	SDL_Event evt;
	const Uint64 ticks_per_frame = SDL_GetPerformanceFrequency() / TARGET_FPS;
	Uint64 start_tick;

	while (!bQuit)
	{
		start_tick = SDL_GetPerformanceCounter();

		// polling for events
		while (SDL_PollEvent(&evt))
		{
			if (evt.type == SDL_QUIT)
			{
				bQuit = true;
			}
			else if (evt.type == SDL_KEYDOWN)
			{
				switch (evt.key.keysym.sym)
				{
				case SDLK_ESCAPE:
					bQuit = true;
					break;

				case SDLK_SPACE:
					if (m_curAmmoCount > 0) {
						--m_curAmmoCount;
						m_updateAmmoTexture();

						m_screenFlashState = 1;
						m_led_flash = true;

						if (m_curAmmoCount == 0)
						{
							m_bReload = true;
							m_reloadFrameCount = 0;
						}
					}
					break;

				case SDLK_r:
					if (m_curAmmoCount < m_maxAmmoCount) {
						m_curAmmoCount = m_maxAmmoCount;
						m_updateAmmoTexture();

						m_bReload = false;
					}
					break;
				}
			}
		}

		// Update the position of Crosshair
		m_updateCrosshairPos();
		m_texCrosshair->setPosition(
			SDL_Point({
				static_cast<int>(m_posCrosshair.x),
				static_cast<int>(m_posCrosshair.y) }));

		// Screen flash effect
		if (m_screenFlashState == 1)
		{
			SDL_SetRenderDrawColor(m_renderer, 0xFF, 0xFF, 0x00, 0xFF);
			m_screenFlashState = 2;
		}
		else if (m_screenFlashState == 2)
		{
			SDL_SetRenderDrawColor(m_renderer, 0x00, 0x00, 0x00, 0xFF);
			m_screenFlashState = 0;
		}

		// Update screen
		SDL_RenderClear(m_renderer);
		m_texCrosshair->render(m_renderer);
		m_texAmmoText->render(m_renderer);
		if (m_bReload)
		{
			m_texReload->setScale((float)(sin((double)m_reloadFrameCount / TARGET_FPS * 2 * M_PI) * 0.1) + 1.0f);
			m_texReload->render(m_renderer);
			(++m_reloadFrameCount) %= TARGET_FPS;
		}
		SDL_RenderPresent(m_renderer);

		// LED Control
		m_doLedCtrl();

		// Wait until frame done
		while (SDL_GetPerformanceCounter() <= start_tick + ticks_per_frame)
			;
	}

	return 0;
}
