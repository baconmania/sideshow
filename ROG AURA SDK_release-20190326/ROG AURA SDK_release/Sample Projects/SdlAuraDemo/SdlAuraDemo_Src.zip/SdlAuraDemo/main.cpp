#include "GameApp.h"
#include <memory>

using namespace std;

int main(int argc, char** argv)
{
	int result = 0;
	{
		auto game = make_unique<GameApp>(SCREEN_WIDTH, SCREEN_HEIGHT);

		result = game->Run();
	}

	return result;
}
