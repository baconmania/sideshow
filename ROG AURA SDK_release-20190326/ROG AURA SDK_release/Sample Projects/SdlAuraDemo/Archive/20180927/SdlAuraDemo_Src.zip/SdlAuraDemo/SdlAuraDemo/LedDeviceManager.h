#ifndef __LED_DEVICE_MANAGER_H__
#define __LED_DEVICE_MANAGER_H__

#import "libid:F1AA5209-5217-4B82-BA7E-A68198999AFA" /* AuraServiceLib */

#include <future>
#include <vector>
#include <map>

enum LedDeviceType
{
	ALL = 0,

	MB_RGB = 0x10000,
	MB_ADDRESABLE = 0x11000,
	DESKTOP_RGB = 0x12000,

	VGA_RGB = 0x20000,

	DISPLAY_RGB = 0x30000,

	HEADSET_RGB = 0x40000,

	MICROPHONE_RGB = 0x50000,

	EXTERNAL_HARD_DRIVER_RGB = 0x60000,
	EXTERNAL_BLUE_RAY_RGB = 0x61000,

	DRAM_RGB = 0x70000,

	KEYBOARD_RGB = 0x80000,
	NB_KB_RGB = 0x81000,
	NB_KB_4ZONE_RGB = 0x81001,

	MOUSE_RGB = 0x90000,

	CHASSIS_RGB = 0xB0000,
	PROJECTOR_RGB = 0xC0000
};

class LedDevice
{
public:
	LedDevice()
		: m_dev()
		, m_type(LedDeviceType::ALL)
		, m_lights(0)
		, m_width(0)
		, m_height(0)
		, m_cached_keys()
	{ }

	LedDevice(const AuraServiceLib::IAuraSyncDevicePtr& dev)
		: LedDevice()
	{
		Initialize(dev);
	}

	void Initialize(const AuraServiceLib::IAuraSyncDevicePtr& dev);

	LedDeviceType GetType() { return m_type; }

	void SetColorToAllLights(COLORREF color);
	void SetColorByScanCode(BYTE scancode, COLORREF color);
	void SetColorByXY(int x, int y, COLORREF color);

	void Apply() { m_dev->Apply(); }
	void CleanUp();

private:
	AuraServiceLib::IAuraSyncDevicePtr m_dev;
	LedDeviceType m_type;
	std::vector<AuraServiceLib::IAuraRgbLightPtr> m_lights;
	ULONG m_width;
	ULONG m_height;

	std::map<USHORT, AuraServiceLib::IAuraRgbLightPtr> m_cached_keys;
};

class LedDeviceManager
{
	AuraServiceLib::IAuraSdk2Ptr m_sdk;
	std::vector<LedDevice> m_devices;

	std::future<HRESULT> m_asyncResult;

public:
	LedDeviceManager();
	~LedDeviceManager();

	size_t GetDeviceCount() { return m_devices.size(); }
	LedDevice& GetDevice(size_t index) { return m_devices[index]; }

	void ApplyAll();
	bool IsReady();
};

#endif
