#include "GameTexture.h"

#include <iostream>

#include <SDL_image.h>

using namespace std;

GameTexture::GameTexture()
	: m_name()
	, m_texture(nullptr)
	, m_rect({ 0, 0, 0, 0 })
	, m_pos({ 0, 0 })
	, m_sizeOriginal({ 0, 0 })
	, m_scale(1.0f)
{
}

GameTexture::GameTexture(const std::string & path, SDL_Renderer* renderer)
	: GameTexture()
{
	loadFile(path, renderer);
}


GameTexture::~GameTexture()
{
	reset();
}

bool GameTexture::loadFile(const std::string & path, SDL_Renderer* renderer)
{
	reset();

	//Load image at specified path
	SDL_Surface* loadedSurface = IMG_Load(path.c_str());
	if (loadedSurface == NULL)
	{
		cout << "Cannot load image " << path.c_str()
			<< "!\nSDL_image Error: " << IMG_GetError() << endl;
		return false;
	}
	else
	{
		//Create texture from surface pixels
		m_texture = SDL_CreateTextureFromSurface(renderer, loadedSurface);
		if (m_texture == NULL)
		{
			cout << "Unable to create texture from " << path.c_str()
				<< "! SDL Error: " << SDL_GetError() << endl;
			return false;
		}

		m_sizeOriginal.x = loadedSurface->w;
		m_sizeOriginal.y = loadedSurface->h;
		m_updateRect();

		//Get rid of old loaded surface
		SDL_FreeSurface(loadedSurface);
	}

	m_name = path;
	return true;
}

bool GameTexture::loadText(const std::string & text, SDL_Color color, TTF_Font& font, SDL_Renderer * renderer)
{
	reset();

	SDL_Surface* loadedSurface = TTF_RenderText_Solid(&font, text.c_str(), color);
	if (!loadedSurface)
	{
		cout << "Cannot render text \"" << text
			<< "\"!\nSDL_ttf Error: " << TTF_GetError() << endl;
		return false;
	}

	//Create texture from surface pixels
	m_texture = SDL_CreateTextureFromSurface(renderer, loadedSurface);
	if (m_texture == NULL)
	{
		cout << "Unable to create text texture!\nSDL Error: "
			<< SDL_GetError() << endl;
		return false;
	}

	m_sizeOriginal.x = loadedSurface->w;
	m_sizeOriginal.y = loadedSurface->h;
	m_updateRect();

	//Get rid of old loaded surface
	SDL_FreeSurface(loadedSurface);

	return true;
}

void GameTexture::render(SDL_Renderer * renderer)
{
	if (m_texture && renderer)
	{
		SDL_RenderCopy(renderer, m_texture, nullptr, &m_rect);
	}
}

void GameTexture::reset()
{
	if (m_texture)
	{
		SDL_DestroyTexture(m_texture);
		m_texture = nullptr;
		m_name = "";
		m_sizeOriginal.x = 0;
		m_sizeOriginal.y = 0;
		m_scale = 1.0f;
		m_pos.x = 0;
		m_pos.y = 0;
		m_updateRect();
	}
}

void GameTexture::setScale(float scale)
{
	m_scale = scale;
	m_updateRect();
}

void GameTexture::setPosition(const SDL_Point& pos)
{
	m_pos.x = pos.x;
	m_pos.y = pos.y;
	m_updateRect();
}

void GameTexture::m_updateRect()
{
	m_rect.w = static_cast<int>(m_scale * m_sizeOriginal.x);
	m_rect.h = static_cast<int>(m_scale * m_sizeOriginal.y);
	m_rect.x = m_pos.x - m_rect.w / 2;
	m_rect.y = m_pos.y - m_rect.h / 2;
}
