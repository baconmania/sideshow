#ifndef __GAME_TEXTURE_H__
#define __GAME_TEXTURE_H__

#include <SDL.h>
#include <SDL_ttf.h>

#include <string>

class GameTexture
{
	std::string m_name;
	SDL_Texture* m_texture;
	SDL_Rect m_rect;
	SDL_Point m_pos;
	SDL_Point m_sizeOriginal;
	float m_scale;

public:
	GameTexture();
	GameTexture(const std::string& path, SDL_Renderer* renderer);

	~GameTexture();

	operator SDL_Texture*() { return m_texture; }

	bool loadFile(const std::string& path, SDL_Renderer* renderer);
	bool loadText(const std::string& text, SDL_Color color, TTF_Font& font, SDL_Renderer* renderer);
	void render(SDL_Renderer* renderer);

	void reset();

	bool isValid() { return (m_texture) ? true : false; }

	float getScale() { return m_scale; }
	void setScale(float scale);

	void setPosition(const SDL_Point& pos);
	const SDL_Point& getPosition() { return m_pos; }

	int getWidth() { return m_sizeOriginal.x; }
	int getHeight() { return m_sizeOriginal.y; }

private:
	void m_updateRect();
};

#endif
