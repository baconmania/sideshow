## Operations

1. WASD  - Move crosshair
2. R     - Reload
3. Space - Shoot
4. ESC   - Quit

## Display

1. There is a crosshair icon that can be moved by W-A-S-D keys.
2. Ammo (max = 10) left count is shown in the left-down conner.
3. The whole screen will flash when Space is pressed to shoot.
4. When ammo left count = 0, there will be a "Reload" instruction in the
   center of the screen.

## Keyboard LED Behavior

1. All keys (except for those described below) perform "breathing" effect
   in BLUE.
2. WASD & Space should be constantly WHITE.
3. When reload is needed, R becomes "breathing" effect in WHITE.
4. F1 ~ F4 indicate ammo left status. GREEN means availble, RED means empty.
5. When Space is pressed to shoot, all LEDs should flash as YELLOW.
