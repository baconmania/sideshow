#include "LedDeviceManager.h"

#include <map>

using namespace AuraServiceLib;
using namespace std;

LedDeviceManager::LedDeviceManager()
	: m_sdk(nullptr)
	, m_devices(0)
{
	HRESULT hr;

	// Initialize COM
	hr = ::CoInitialize(nullptr);
	if (SUCCEEDED(hr))
	{
		// Create SDK instance
		hr = m_sdk.CreateInstance(__uuidof(AuraSdk), nullptr, CLSCTX_INPROC_SERVER);
		if (SUCCEEDED(hr))
		{
			// Acquire control
			m_sdk->SwitchMode();

			// Enumerate all keyboard devices
			auto devs = m_sdk->Enumerate(LedDeviceType::ALL);
			auto count = devs->Count;
			for (int i = 0; i < count; i++)
			{
				LedDevice dev(devs->Item[i]);

				m_devices.push_back(dev);
			}
		}
	}
}

LedDeviceManager::~LedDeviceManager()
{
	// Release resources before uninitializing COM
	for (int i = 0; i < m_devices.size(); i++)
	{
		m_devices[i].CleanUp();
	}
	// Note: we use _com_ptr_t<>::Release(), NOT IUnknown::Release()!!
	m_sdk.Release();

	// Uninitialize COM
	::CoUninitialize();
}

void LedDeviceManager::ApplyAll()
{
	// LED I/O is time consuming. So we use async and execute I/O operations
	// in the background.
	m_asyncResult = async(
		launch::async,
		[&]() {
			for (auto& device : m_devices)
			{
				device.Apply();
			}
			return S_OK;
		}
	);
}

bool LedDeviceManager::IsReady()
{
	// std::future::valid() & std::fugure::wait_for() are used to check if
	// the async operation has been done.
	bool result = true;
	if (m_asyncResult.valid())
	{
		if (m_asyncResult.wait_for(chrono::milliseconds(0)) != future_status::ready)
		{
			result = false;
		}
	}
	return result;
}

void LedDevice::Initialize(const AuraServiceLib::IAuraSyncDevicePtr & dev)
{
	m_dev = dev;

	auto lights = m_dev->Lights;
	auto light_count = lights->Count;
	for (int j = 0; j < light_count; j++)
	{
		m_lights.push_back(lights->Item[j]);
	}

	m_width = m_dev->Width;
	m_height = m_dev->Height;
	m_type = static_cast<LedDeviceType>(m_dev->Type);
}

void LedDevice::SetColorToAllLights(COLORREF color)
{
	for (auto& light : m_lights)
	{
		light->Color = color;
	}
}

void LedDevice::SetColorByScanCode(BYTE scancode, COLORREF color)
{
	auto iter = m_cached_keys.find(scancode);
	if (iter == m_cached_keys.end())
	{
		// We need get IAuraSyncKeyboardPtr to use its GetKey() method.
		IAuraSyncKeyboardPtr kb;
		m_dev.QueryInterface(__uuidof(IAuraSyncKeyboard), kb.GetInterfacePtr());
		if (!kb)
		{
			return;
		}
		m_cached_keys[scancode] = kb->GetKey(scancode);
	}
	m_cached_keys[scancode]->Color = color;
}

void LedDevice::SetColorByXY(int x, int y, COLORREF color)
{
	if (static_cast<ULONG>(x) < m_width && static_cast<ULONG>(y) < m_height)
	{
		m_lights[y * m_width + x]->Color = color;
	}
}

void LedDevice::CleanUp()
{
	// Note: we use _com_ptr_t<>::Release(), NOT IUnknown::Release()!!
	for (auto& light : m_lights)
	{
		light.Release();
	}

	for (auto& pair : m_cached_keys)
	{
		pair.second.Release();
	}

	m_dev.Release();
}
