#ifndef __GAME_APP_H__
#define __GAME_APP_H__

#include <memory>
#include <string>
#include <SDL.h>
#include <SDL_ttf.h>

#include "GameTexture.h"
#include "KL_Vector.h"
#include "LedDeviceManager.h"

constexpr int SCREEN_WIDTH = 640;
constexpr int SCREEN_HEIGHT = 480;

class GameApp
{
	std::unique_ptr<LedDeviceManager> m_ledDevMgr;
	bool m_bInitOk;
	int m_width;
	int m_height;
	SDL_Window* m_window;
	SDL_Renderer* m_renderer;
	TTF_Font* m_font;

	GameTexture* m_texCrosshair;
	GameTexture* m_texAmmoText;
	GameTexture* m_texReload;

	KL_Vector2D m_posCrosshair;
	float m_velocity;

	int m_maxAmmoCount;
	int m_curAmmoCount;

	int m_screenFlashState;

	bool m_bReload;
	int m_reloadFrameCount;

	int m_led_breathingFrame;
	bool m_led_flash;
	int m_led_reloadFrame;

public:
	GameApp(int width = SCREEN_WIDTH, int height = SCREEN_HEIGHT);
	~GameApp();

	int Run();

private:
	void m_init();
	void m_loadMedia();
	void m_updateCrosshairPos();
	void m_updateAmmoTexture();

	void m_doLedCtrl();
};

#endif
